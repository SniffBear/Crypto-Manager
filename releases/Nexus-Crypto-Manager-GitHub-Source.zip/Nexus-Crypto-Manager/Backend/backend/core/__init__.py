"""Solana Vault backend module."""
