"""On-chain synchronization services for Solana Vault."""
