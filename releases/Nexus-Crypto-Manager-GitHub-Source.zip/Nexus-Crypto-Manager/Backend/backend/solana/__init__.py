"""Native Solana RPC integration used by the wallet-first sync engine."""
